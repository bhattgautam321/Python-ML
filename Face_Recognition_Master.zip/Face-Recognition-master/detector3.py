import cap as cap
import cv2,os
import numpy as np
from PIL import Image 

path = os.path.dirname(os.path.abspath(__file__))

#recognizer = cv2.createLBPHFaceRecognizer()
recognizer = cv2.face.LBPHFaceRecognizer_create();

recognizer.read(path+r'\\trainer\\trainer.yml')
cascadePath = path+"\\Classifiers\\face.xml"
faceCascade = cv2.CascadeClassifier(cascadePath);

cam = cv2.VideoCapture(0)
#font = cv2.CV_FONT_HERSHEY_SIMPLEX #Creates a font
font = cv2.CASCADE_SCALE_IMAGE


while True:
    ret, im =cam.read()
    gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
    faces=faceCascade.detectMultiScale(gray, scaleFactor=1.2, minNeighbors=5, minSize=(100, 100), flags=cv2.CASCADE_SCALE_IMAGE)
    for(x,y,w,h) in faces:
        id, conf = recognizer.predict(gray[y:y+h,x:x+w])
        cv2.rectangle(im,(x-50,y-50),(x+w+50,y+h+50),(225,0,0),2)
        if id == 1:
            id = "Gautam"
            print("This is Gautam")
        elif id == 2:
            id = "Mohit"
            print("This is Mohit")
        elif id == 3:
            id = "Ashish Karn"
            print("This is Ashish Karn")
        elif id == 2:
            id = "Shivang Jalan"
            print("This is Shivang Jalan")
        else:
            print("Sorry unable to recognize it")
        cv2.putText(im,str(id)+"--"+str(conf), (x,y+h),font, 1.1, (0,255,0)) #Draw the text
        # cv2.imshow('im',im)
        # cv2.waitKey()
    cv2.imshow('im', im)
    if cv2.waitKey(1) == ord('q'):
        break
cap.release()
cv2.destroyAllWindows()









